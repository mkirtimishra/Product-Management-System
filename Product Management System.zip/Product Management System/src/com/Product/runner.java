package com.Product;

import java.util.*;

public class runner {
    public static Scanner sc=new Scanner(System.in);
    static Map<Integer, product> map=new HashMap<>();
    public static void Add_fuct(){
        System.out.println("Enter product id");
        int p_id=sc.nextInt();
        System.out.println("Enter product name");
        String p_name=sc.next();
        System.out.println("Enter product category");
        String p_catagory=sc.next();
        System.out.println("Enter product price");
        double p_price=sc.nextDouble();
        System.out.println("Enter product quantity");
        int p_quan=sc.nextInt();

        product p=new product(p_id, p_name, p_catagory, p_price, p_quan);
        map.put(p_id,p);
    }

    public static void Delete_fuct(){
        System.out.println("Enter Product id, which you want to delete");
        int p_id=sc.nextInt();
        if(map.containsKey(p_id)){
            map.remove(p_id);
        }
        System.out.println("Remove Sucess");
    }

    public static void Search_fuct(){
        System.out.println("Enter Product id, which you want to search");
        int p_id=sc.nextInt();
        if(map.containsKey(p_id)){
            System.out.println(map.get(p_id));
        }
        else{
            System.out.println("Please, Enter valid id...");
        }
    }

    public static void View_fuct(){
        System.out.println("List of Products...");
        for(Map.Entry<Integer,product> entry : map.entrySet()){
            // System.out.println(entry.getKey() +"=="+entry.getValue());
            System.out.println(entry.getValue());
        }
    }

    public static void Edit_fuct(){
        Add_fuct();
    }

    public static void Exitt(){
        System.out.println("Thank You..... :)");
        System.exit(0);

    }

    public static void main(String args[]) {
        Scanner sc=new Scanner(System.in);
        String user_name="user";
        String password="pass";
        System.out.println("       Log-In.......  ");
        System.out.println();
        System.out.println("Please, Enter Username");
        String username=sc.next();
        System.out.println("Please, Enter Password");
        String paswrd=sc.next();
        int option=0;

        if(user_name.equals(username) && password.equals(paswrd)){
            do{
                System.out.println("Choose the option");
                System.out.println("1. Add Product");
                System.out.println("2. Delete Product");
                System.out.println("3. Search Product");
                System.out.println("4. View Product");
                System.out.println("5. Edit Product");
                System.out.println("6. Exit");

                option=sc.nextInt();
                switch (option) {
                    case 1:
                        Add_fuct();
                        break;
                    case 2:
                        Delete_fuct();
                        break;
                    case 3:
                        Search_fuct();
                        break;
                    case 4:
                        View_fuct();
                        break;
                    case 5:
                        Edit_fuct();
                        break;
                    case 6:
                        Exitt();
                        break;

                    default:
                        System.out.println("Please, Enter Valid Option....");
                        break;
                }

            }while(option!=6);
        }
        else{
            System.out.println("Please, Enter Valid Username & Password.... :)");

        }
        sc.close();
        System.out.println("Thank You...!");

    }
}
