package com.Product;
//import java.util.*;
public class product {
    int product_id;
    String product_name;
    String product_category;
    double product_price;
    int product_quantity;

    product(int product_id, String product_name, String product_category, double product_price,  int product_quantity){
        this.product_id=product_id;
        this.product_name=product_name;
        this.product_category=product_category;
        this.product_price=product_price;
        this.product_quantity=product_quantity;
    }
    public String toString(){
        return "product [product_id=" + product_id + ", product_name=" +product_name+ ", product_category=" +product_category+ ", product_price=" +product_price+ ",product_quantity=" +product_quantity+ "]";
    }
}
